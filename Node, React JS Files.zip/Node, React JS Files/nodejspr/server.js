const express = require('express')
const app = express()
const port = 3001
var cors = require('cors');
app.use(cors());
app.set("view engine", "ejs");
const bodyparser = require("body-parser");
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }));
const mongoose = require("mongoose");
mongoose.set('strictQuery', false);
mongoose.connect("mongodb://0.0.0.0:27017/ssddb", {useNewUrlParser: true});
// import bcrypt from 'bcrypt'
const bcrypt = require('bcrypt')

const userSchema = {

    name : String,
    email: String,
    password : String,
};
const usersModel = mongoose.models.usersModel || mongoose.model('users', userSchema);


const questionsSchema = {
    ques: String,
    ans : String,
    timestamp: {
        type: Date,
        default: Date.now
    }
};
const questionsModel = mongoose.models.questionsModel || mongoose.model('questions', questionsSchema);

const historySchema = {
    email : String,
    ques: String,
    ans : String,
    timestamp: {
        type: Date,
        default: Date.now
    }
};
const historyModel = mongoose.models.historyModel || mongoose.model('history', historySchema);

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/register', async (req, res) => {
    console.log(req.body.email)
    const hashedPassword = await bcrypt.hash(req.body.password, 10);

    const newUser = new usersModel({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
    });

    usersModel.find({email : req.body.email}).then((data) => {
        console.log(data)
        if(data[0] != undefined){
            console.log("Enteredd")
            res.send({"statuss" : "already"})
            res.end()
        }
        else{
            newUser.save().then(()=>{
                res.send({"statuss" : "success"})
               
            }).catch((err)=>{
                console.log(err);
            })
            console.log("Entered")
        }
    })
    
})

app.post('/inshistory', (req, res) => {
    console.log(req.body)
    const newHistory = new historyModel({
        email: req.body.email_id,
        ques: req.body.selectedQuestion.ques,
        ans : req.body.selectedQuestion.ans,
    });

   
    newHistory.save().then(()=>{
                res.send({"statuss" : "success"})
               
            }).catch((err)=>{
                console.log(err);
            })
            console.log("Entered")
        
    
})


app.post('/insq', (req, res) => {

    const newQues = new questionsModel({
        ques: req.body.ques,
        ans: req.body.ans
    });

    
            newQues.save().then(()=>{
                res.send({"statuss" : "success"})
            }).catch((err)=>{
                console.log(err);
            })
            console.log("Entered")
    
})

app.get('/questionsapi', (req, res) => {
    questionsModel.find()
    .sort({ timestamp: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        // console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });

    
})


app.post('/historyapi', (req, res) => {
    console.log(req.body.email_id)
    historyModel.find({email : req.body.email_id})
    .sort({ timestamp: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });
})

app.post('/historydeleteapi', (req, res) => {
    console.log(req.body)
    historyModel.deleteMany({ email: req.body.email_id })
        .exec()
        .then(() => {
            res.send({ message: `Deleted all records with email ID` });
        })
        .catch((err) => {
            console.error(err);
            res.status(500).send('Internal Server Error');
        });
})


app.post('/editquestion', (req, res) => {
    console.log(req.body)
    questionsModel.deleteMany({ _id: req.body.currqid })
        .exec()
        .then(() => {

            if(req.body.deleteqq){
                const newQues = new questionsModel({
                    ques: req.body.ques,
                    ans: req.body.ans
                });

                        newQues.save().then(()=>{
                            res.send({"statuss" : "success"})
                        }).catch((err)=>{
                            console.log(err);
                        })
                        console.log("Entered")
            }
            else{
                res.send({"statuss" : "success"})

            }
            console.log("Done")
        })
        .catch((err) => {
            console.error(err);
            res.status(500).send('Internal Server Error');
        });
})

app.post('/login', async (req, res) => {
    console.log(req.body.email)

    const user = await usersModel.findOne({ email: req.body.email })

    usersModel.find({email : req.body.email}).then(async (data) => {
        console.log(data)
        if(data[0] != undefined){
            const userAllowed = await bcrypt.compare(req.body.password, user.password)
            if(userAllowed){
                res.send({"statuss" : "logged"})
            }
            else{
                res.send({"statuss" : "exists"})
        
            }
        }
        else{
            res.send({"statuss" : "no"})
        }
    })
    
    
    // 2. compare the password from req vs password in db - Authenticated ok
        
    
})
    


    




app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})