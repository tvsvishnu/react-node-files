const express = require('express')
const app = express()
const port = 3001
var cors = require('cors');
app.use(cors());
app.set("view engine", "ejs");
const bodyparser = require("body-parser");
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }));
const mongoose = require("mongoose");
mongoose.set('strictQuery', false);
mongoose.connect("mongodb://0.0.0.0:27017/ssddb", {useNewUrlParser: true});
const bcrypt = require('bcrypt')

const userSchema = {

    email: String,
    password : String,
};
const usersModel = mongoose.models.usersModel || mongoose.model('ssdlab7users', userSchema);
const todoSchema = {
    email : String,
    title: String,
    description : String,
    duedate : Date,
    status : Boolean,
};
const todoModel = mongoose.models.todoModel || mongoose.model('todos', todoSchema);



app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/register', async (req, res) => {
    console.log(req.body.email)
    const hashedPassword = await bcrypt.hash(req.body.password, 10);

    const newUser = new usersModel({
        email: req.body.email,
        password: hashedPassword
    });

    usersModel.find({email : req.body.email}).then((data) => {
        console.log(data)
        if(data[0] != undefined){
            console.log("Enteredd")
            res.send({"statuss" : "already"})
            res.end()
        }
        else{
            newUser.save().then(()=>{
                res.send({"statuss" : "success"})
               
            }).catch((err)=>{
                console.log(err);
            })
            console.log("Entered")
        }
    })
    
})

app.post('/todoinsert', async (req, res) => {
    // console.log(req.body.email)
    // const hashedPassword = await bcrypt.hash(req.body.password, 10);

    const newTodo = new todoModel({
        email : req.body.email,
        title : req.body.title,
        description : req.body.desc,
        duedate : req.body.dob,
        status : false
    });

    
            newTodo.save().then(()=>{
                res.send({"statuss" : "success"})
               
            }).catch((err)=>{
                console.log(err);
            })
            console.log("Entered")
        
    
    
})

// app.post('/inshistory', (req, res) => {
//     console.log(req.body)
//     const newHistory = new historyModel({
//         email: req.body.email_id,
//         ques: req.body.selectedQuestion.ques,
//         ans : req.body.selectedQuestion.ans,
//     });

   
//     newHistory.save().then(()=>{
//                 res.send({"statuss" : "success"})
               
//             }).catch((err)=>{
//                 console.log(err);
//             })
//             console.log("Entered")
        
    
// })


// app.post('/insq', (req, res) => {

//     const newQues = new questionsModel({
//         ques: req.body.ques,
//         ans: req.body.ans
//     });

    
//             newQues.save().then(()=>{
//                 res.send({"statuss" : "success"})
//             }).catch((err)=>{
//                 console.log(err);
//             })
//             console.log("Entered")
    
// })

app.post('/todoapi', (req, res) => {
    todoModel.find({email : req.body.email})
    .sort({ date: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        // console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });

    
})

app.post('/completedtodoapi', (req, res) => {
    // const today = new Date();

    todoModel.find({email : req.body.email, status : true })
    .sort({ date: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        // console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });
})

app.post('/changestatus', (req, res) => {
    // const today = new Date();
    const _id = req.body._id
    todoModel.updateOne(
        { _id },
        { $set: { status: true } },
        { new: true } // Set new to true to return the updated document
      )
    .sort({ date: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        // console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });
})

app.post('/deletetodo', (req, res) => {
    // const today = new Date();

    todoModel.deleteMany({_id : req.body._id })
    .sort({ date: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        // console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });
})
app.post('/pendingtodoapi', (req, res) => {
    todoModel.find({email : req.body.email, status : false })
    .sort({ date: -1 }) 
    .exec()
    .then((questions) => {
        console.log('Questions sorted by timestamp (ascending):');
        // console.log(questions)
        res.send({ "questions": questions }); 
    })
    .catch((err) => {
        console.error(err);
        res.status(500).send('Internal Server Error'); 
    });
})

// app.post('/historyapi', (req, res) => {
//     console.log(req.body.email_id)
//     historyModel.find({email : req.body.email_id})
//     .sort({ timestamp: -1 }) 
//     .exec()
//     .then((questions) => {
//         console.log('Questions sorted by timestamp (ascending):');
//         console.log(questions)
//         res.send({ "questions": questions }); 
//     })
//     .catch((err) => {
//         console.error(err);
//         res.status(500).send('Internal Server Error'); 
//     });
// })

// app.post('/historydeleteapi', (req, res) => {
//     console.log(req.body)
//     historyModel.deleteMany({ email: req.body.email_id })
//         .exec()
//         .then(() => {
//             res.send({ message: `Deleted all records with email ID` });
//         })
//         .catch((err) => {
//             console.error(err);
//             res.status(500).send('Internal Server Error');
//         });
// })


// app.post('/editquestion', (req, res) => {
//     console.log(req.body)
//     questionsModel.deleteMany({ _id: req.body.currqid })
//         .exec()
//         .then(() => {

//             if(req.body.deleteqq){
//                 const newQues = new questionsModel({
//                     ques: req.body.ques,
//                     ans: req.body.ans
//                 });

//                         newQues.save().then(()=>{
//                             res.send({"statuss" : "success"})
//                         }).catch((err)=>{
//                             console.log(err);
//                         })
//                         console.log("Entered")
//             }
//             else{
//                 res.send({"statuss" : "success"})

//             }
//             console.log("Done")
//         })
//         .catch((err) => {
//             console.error(err);
//             res.status(500).send('Internal Server Error');
//         });
// })

app.post('/login', async (req, res) => {
    console.log(req.body.email)

    const user = await usersModel.findOne({ email: req.body.email })

    usersModel.find({email : req.body.email}).then(async (data) => {
        console.log(data)
        if(data[0] != undefined){
            const userAllowed = await bcrypt.compare(req.body.password, user.password)
            if(userAllowed){
                res.send({"statuss" : "logged"})
            }
            else{
                res.send({"statuss" : "exists"})
        
            }
        }
        else{
            res.send({"statuss" : "no"})
        }
    })
    
    
    // 2. compare the password from req vs password in db - Authenticated ok
        
    
})
    


    




app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})