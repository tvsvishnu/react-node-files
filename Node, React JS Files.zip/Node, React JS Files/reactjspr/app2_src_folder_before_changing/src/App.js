import './App.css';
// import StartPage from './register';
// import ErrorPage from './errorpage';
import LoginPage from './login';
import RegisterPage from './register';
import TodoPage from './todopage';
// import HistoryPage from './historypage';
// import AdminPage from './adminpage';
import { BrowserRouter as Router, Link ,Routes,Route } from "react-router-dom";
import Cookies from 'universal-cookie';
import { useState } from 'react';
import LogoutPage from './logout';
import TodoDisplay from './completedtodo';
import PendingTodos from './pendingtodos';
// import QuestionsPage from './questions';
// import AdminEditbyid from './editquesion';
function App() {

  var cook = new Cookies();
  var email_id = cook.get("email_id");
  var loggedin = cook.get("logged_in");
  return (
    <div className="App">
<Router>

<Routes>        

   {loggedin === true ? 
   <>
   <Route path='/login' element={<LoginPage /> }/>
   <Route path='/register' element={<RegisterPage />} />
   <Route path='/logout' element={<LogoutPage />} />
   <Route path='/todo' element={<TodoPage />} />
   <Route path='/completed' element={<TodoDisplay />} />
   <Route path='/pending' element={<PendingTodos />} />
   <Route path='*' element={<LoginPage />} />

      </>
      : <><Route path='/login' element={<LoginPage /> }/>
         <Route path='/register' element={<RegisterPage />} />

      <Route path='*' element={<LoginPage />} />

      </>
  }
    

    </Routes>
    
    </Router>



    </div>
  );
}

export default App;
