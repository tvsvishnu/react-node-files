import React from "react";
import axios from "axios";
import moment from 'moment-timezone'
import 'semantic-ui-css/semantic.min.css';


import { useState } from "react";
import { Input } from "semantic-ui-react";
import {Button} from 'semantic-ui-react'
import NAvbar from "./navbar";
import { useNavigate } from "react-router-dom";
import Cookies from "universal-cookie";
function TodoPage(props) {
    var cookies = new Cookies();
    const [formData, setFormdata] = useState({email : cookies.get("email_id")})
    const handleChange = (e) => {
        setFormdata({ ...formData, [e.target.name]: e.target.value });
    }
    var navigate = useNavigate();
    function handleSub(e) {
        e.preventDefault()
        axios.post('http://localhost:3001/todoinsert', formData).then((response) => {
            console.log(formData)
            console.log("Success");
            if(response.data.statuss === "success"){
                alert("Todo Created Succesfully");
                navigate('/pending')
                
            }
            else{
                alert("Error");
                navigate('/todo')

            }
            console.log(response.data.statuss)
        }).catch((e) => {
            console.log(e.response.data);
           
        });
    }

    return (
        <div>
            <h1>SSD Lab 8</h1><NAvbar></NAvbar><hr></hr>
            <h1>Todo Page</h1>
            <form onSubmit={handleSub} method="post" >
                <b>Title : </b><Input onChange={handleChange} placeholder='Enter Title' name="title" /><br></br><br></br>
                <b>Description : </b><Input onChange={handleChange} placeholder='Enter Description' name="desc" /><br></br><br></br>
                {/* <b>Answer : </b><Input onChange={handleChange} placeholder='Enter Answer' name="ans" /> */}

                <b>Date</b> : <Input type="date" placeholder="Date of Birth" name="dob" onChange={handleChange} min={moment().format("YYYY-MM-DD")}/>

                <br></br><br></br>
                {/* <Button primary>Click</Button> */}
                <button class="button ui primary button">Submit</button>
            </form>


        </div>
    );
}
export default TodoPage;