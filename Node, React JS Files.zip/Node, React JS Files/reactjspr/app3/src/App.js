import React, { useState, useEffect } from 'react';
import {Button} from 'semantic-ui-react';

import Cookies from 'universal-cookie';
import './App.css';

function App() {
  const [activeTimer, setActiveTimer] = useState(1);
  var cook = new Cookies();
  cook.set("time", 1);
  var minutes_provided = cook.get("time");
  const [seconds, setSeconds] = useState(minutes_provided * 60);
  const [seconds2, setSeconds2] = useState(minutes_provided * 60);
  const [curr, setcurr] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      if(curr == 0){
        setSeconds(seconds - 1);

      }
    }, 1000);

    return () => clearInterval(timer);
  }, [seconds, curr]);
  useEffect(() => {
    const timer2 = setInterval(() => {
      if(curr == 1){
        setSeconds2(seconds2 - 1);

      }
    }, 1000);

    return () => clearInterval(timer2);
  }, [seconds2, curr]);

  const changeactive = (e) => {
    setcurr(1 - curr);
  }
  return (
    <center>
<>


<h1>9 Men Morris Game</h1>
<hr></hr>
<div class="row">
<div class="column"><h1>Sample Board</h1></div>
<div class="column">

<center>


<Button onClick={changeactive}>Play and Click</Button> <br></br> <hr></hr>
<div class="timer">
{seconds > 0 ? <h1>White - {seconds}</h1> : <h1>Black Won</h1>}
</div>

<br></br>
<div class="timer">
{seconds2 > 0 ? <h1>Black - {seconds2}</h1> : <h1>White Won</h1>}

</div>
</center>


</div>


</div>


</></center>
   


  );
}

export default App;
