import React from "react";
import axios from "axios";
import 'semantic-ui-css/semantic.min.css';


import { useState } from "react";
import { Input } from "semantic-ui-react";
import {Button} from 'semantic-ui-react'
import NAvbar from "./navbar";
function RegisterPage(props) {
    const [formData, setFormdata] = useState({})
    const handleChange = (e) => {
        setFormdata({ ...formData, [e.target.name]: e.target.value });
    }
    function handleSub(e) {
        e.preventDefault()

        // console.log(formData)
        // alert(formData.time);
        axios.post('http://localhost:3001/register', formData).then((response) => {
            console.log(formData)
            console.log("Success");
            if (response.data.statuss == "already") {
                alert("User Already Exists");
            }
            else {
                alert("Registration Succesful");

            }
            console.log(response.data.statuss)
            // alert(response.hi)
        }).catch((e) => {
            console.log(e.response.data);
            //this console logs Error: Network Error
            // at createError (monkeytype.js:formatted:35086:25)
            // at XMLHttpRequest.handleError (monkeytype.js:formatted:34457:28)
        });
    }

    return (
        <div>
            <h1>GPT Lite</h1><hr></hr>      <NAvbar></NAvbar>

            <h1>Registration Page</h1>
            <form onSubmit={handleSub} method="post" >
                <b>Name : </b><Input onChange={handleChange} placeholder='Enter Name' name="name" /><br></br><br></br>
                <b>Email ID : </b><Input onChange={handleChange} placeholder='Enter Email ID' name="email" /><br></br><br></br>
                <b>Password : </b><Input onChange={handleChange} placeholder='Enter Password' type="password" name="password" />
                <br></br><br></br>
                {/* <Button primary>Click</Button> */}
                <button class="button ui primary button">Submit</button>
            </form>


        </div>
    );
}
export default RegisterPage;