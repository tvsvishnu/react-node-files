// import React from "react";
// import axios from "axios";
// import { useState } from "react";
// import {Input, Button} from "semantic-ui-react"
// function SpotifyAPI(props) {
    
    
//     const {data} = axios.get("https://api.spotify.com/v1/search", {
//         headers: {
//             Authorization: 'Bearer ${"BQCcrQNTOGSHnB674vnvN2UwgcU7A4LJT6x535A0wz6an0g_8yEQqrUCx-eU8cH8fkXDfbE_3subdu9JsZCMGcf46gngkFi3qa9jMXaNFGxVD00RVNU"}'
//         },
//         params :{
//             q : "Thaman",
//             type : "artist"
//         }
//     })
//     console.log(data)
//     return (
//         <div>
//             <h1>Spotify API</h1>

//             <hr></hr>
//             {/* <form onSubmit={handleSub} method="post" >
//                 <b>Email ID : </b><Input onChange={handleChange} placeholder='Enter Email ID' name="email" /><br></br><br></br>
//                 <b>Password : </b><Input onChange={handleChange} placeholder='Enter Password' type="password" name="password" />
//                 <br></br><br></br>
//                 <button class="button ui primary">Submit</button>
//             </form> */}


//         </div>
//     );
// }
// export default SpotifyAPI;