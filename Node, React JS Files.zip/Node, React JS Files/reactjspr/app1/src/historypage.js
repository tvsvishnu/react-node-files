import React from "react";
import axios from "axios";
import 'semantic-ui-css/semantic.min.css';
import { Grid, Image, Segment } from 'semantic-ui-react'
import { useState, useEffect, useRef, useLayoutEffect } from "react";
import { Input, Dropdown } from "semantic-ui-react";
import { Button } from 'semantic-ui-react'
import Cookies from "universal-cookie";
import NAvbar from "./navbar";
function HistoryPage(props) {
  const [formData, setFormdata] = useState({})
  const [questions, setQuestions] = useState([]);
  var cook = new Cookies();
  var email_id = cook.get('email_id');
  useEffect(() => {
    async function fetchData() {
      axios.post('http://localhost:3001/historyapi', {"email_id": email_id}).then((response) => {
        const questions = response.data.questions
        setQuestions(questions)
      })
    }
    fetchData();
  }, []);
  console.log(questions)
  
  return (
    <div>
      <div>
        <div>
          <h1>GPT Lite</h1>
          <hr />      <NAvbar></NAvbar>

          <h1>History</h1>
          <div>
            <div>
              <h2>Email ID : {email_id}</h2><hr></hr>
              </div>

            <center>
              <div
                id="displayanswers"
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <Grid columns={3}>
                  {questions.map((question, index) => (
                    <Grid.Row key={index}>
                      <Grid.Column width={5}>
                        <Segment>
                          <b>Question:</b> {question.ques}
                          <br /><br />
                          <b>Answer:</b> {question.ans}
                        </Segment>
                      </Grid.Column>
                    </Grid.Row>
                  ))}
                </Grid>
              </div>
            </center>

          </div>
        </div>
      </div>
    </div>
  );
}


export default HistoryPage;