import axios from 'axios'
import { Button, Menu, Grid, Segment ,Modal, Dropdown, Input, Checkbox } from 'semantic-ui-react'
import { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import NAvbar from './navbar';
import React from 'react';
function AdminEditbyid(props) {
  var qidd = useParams()

  var qidmain = qidd.qidd
  console.log(qidmain)
  const [qidddd, setQID] = useState(false);

  const [questions, setQuestions] = useState(false);
  const [formData, setFormdata] = useState({})
  useEffect(() => {
    async function fetchData() {
      axios.get('http://localhost:3001/questionsapi').then((response) => {
        const questions = response.data.questions
        setQuestions(questions)
        const newFormData = { ...formData };
        newFormData["currqid"] = questions[qidmain]._id;
        newFormData["ques"] = questions[qidmain].ques;
        newFormData["ans"] = questions[qidmain].ans;
        newFormData["deleteqq"] = true;
        setFormdata(newFormData);

      })
    }
    fetchData();
  }, []);
//   function fetchData() {
//     axios.get('https://localhost:3001/questionsapi').then(
//       response => {
//         alert("Enter")
//         console.log("inn");
//         setQID(qidmain);
//         setQuestions(response.data.questions);
//         setFormdata({...formData, ["currqid"] : questions[qidddd]._id});
//       }).then(
//         ()=>{
//           console.log(questions);
//         }
//       )

//   }
//   useEffect(fetchData, [])

//   useEffect(()=>{},[questions])

  const [open, setOpen] = React.useState(false)
  const [sub, setsub] = useState(false)
  const handleChange = (e) => {
    setFormdata({...formData, [e.target.name] : e.target.value});
    console.log(formData)
  }
  const handleCheck = (e) => {
    setFormdata({...formData, ["deleteqq"] : !formData["deleteqq"]});
    console.log(formData)
  }
  var navig = useNavigate();

  function handleSub(e) {
    e.preventDefault()
    // console.log(formData)
    // console.log(data.checked)
    console.log(formData)
    axios.post('http://localhost:3001/editquestion', formData).then((response) => {
      // setsub(true);
      // setOpen(true);
      // console.log(response)
      alert("Question Edited")
      navig('/questions')
    })
  }


  return (<center>
    <div>
      <h1>Admin Page - Edit Question</h1>
      <NAvbar /> 

      {questions ?<> <form onSubmit={handleSub} method="POST">

        <br></br><br></br>
        <input hidden readOnly name="currqid" value= {questions[qidmain]._id}/>
        <b>Question : </b> <Input placeholder='Question' onChange={handleChange} name="ques" defaultValue={questions[qidmain].ques} /><br></br><br></br>
        {/* <b>Option A : </b> <Input placeholder='Option A' onChange={handleChange} name="op1" defaultValue={questions[qidddd].op1} /><br></br><br></br>
        <b>Option B : </b> <Input placeholder='Option B' onChange={handleChange} name="op2" defaultValue={questions[qidddd].op2} /><br></br><br></br>
        <b>Option C : </b> <Input placeholder='Option C' onChange={handleChange} name="op3" defaultValue={questions[qidddd].op3} /><br></br><br></br>
        <b>Option D : </b> <Input placeholder='Option D' onChange={handleChange} name="op4" defaultValue={questions[qidddd].op4} /><br></br><br></br> */}
        <b>Correct Option : </b> <Input placeholder='Answer' onChange={handleChange} name="ans" defaultValue={questions[qidmain].ans} /><br></br><br></br>
        {/* <b>Marks for Correct : </b> <Input placeholder='Marks' onChange={handleChange} name="pos" defaultValue={questions[qidddd].marks} /><br></br><br></br>
        <b>Negative Marking : </b> <Input placeholder='Negative Marks' onChange={handleChange} name="neg" defaultValue={questions[qidddd].neg} /><br></br><br></br> */}
       
<Checkbox label="Check this for deleting the question" onChange={handleCheck} name = "deleteqq" ></Checkbox>

        <br></br>
        <br></br>
      
        <Button content='Submit' primary />
      </form> 
       {open ? 

        <Modal
              centered={true}
              open={true}
              onClose={() => setOpen(false)}
            >
              <Modal.Header>Objective Test Software</Modal.Header>
              <Modal.Content>
                <Modal.Description style={{color:"Black"}}>
                  Question Edited Successfully.
                </Modal.Description>
              </Modal.Content>
              <Modal.Actions>
                <Button primary onClick={() => setOpen(false)}>OK</Button>
              </Modal.Actions>
            </Modal> : <></>}
            </>
      
      : <h1>Loading ... </h1>}
    </div></center>
  );

}

export default AdminEditbyid;