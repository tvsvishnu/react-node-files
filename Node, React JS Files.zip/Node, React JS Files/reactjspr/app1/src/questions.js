import React from "react";
import axios from "axios";
import 'semantic-ui-css/semantic.min.css';
import { Grid, Image, Segment } from 'semantic-ui-react'
import { useState, useEffect, useRef, useLayoutEffect } from "react";
import { Input, Dropdown } from "semantic-ui-react";
import { Button } from 'semantic-ui-react'
import Cookies from "universal-cookie";
import NAvbar from "./navbar";
import { useNavigate } from "react-router-dom";
function QuestionsPage(props) {
  const [questions2, setQuestions2] = useState([]);
  useEffect(() => {
    async function fetchData() {
      axios.get('http://localhost:3001/questionsapi').then((response) => {
        const questions = response.data.questions
        setQuestions2(questions)
      })
    }
    fetchData();
  }, []);

  var history = useNavigate();

  const handleEdit = (e) => {
    
    var qid2 = e;
    history('/editquestion/' + qid2)
  }
  return (
    <div>
      <div>
        <div>
          <h1>GPT Lite</h1>
          <hr />      <NAvbar></NAvbar>

          <h1>All Questions</h1>
          <div>
            <center>
              <div
                id="displayanswers"
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <Grid columns={3}>
                  {questions2.map((question, index) => (
                    <Grid.Row key={index}>
                      <Grid.Column width={5}>
                        <Segment>
                          <b>Question:</b> {question.ques}   <Button name={index} onClick={()=> handleEdit(index)} icon='edit' positive />
                          <br /><br />
                          <b>Answer:</b> {question.ans}
                        </Segment>
                      </Grid.Column>
                    </Grid.Row>
                  ))}
                </Grid>
              </div>
            </center>

          </div>
        </div>
      </div>
    </div>
  );
}


export default QuestionsPage;