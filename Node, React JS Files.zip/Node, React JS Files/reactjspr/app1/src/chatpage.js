import React from "react";
import axios from "axios";
import 'semantic-ui-css/semantic.min.css';
import { Grid, Image, Segment } from 'semantic-ui-react'
import { useState, useEffect, useRef, useLayoutEffect } from "react";
import { Input, Dropdown } from "semantic-ui-react";
import { Button } from 'semantic-ui-react'
import Cookies from "universal-cookie";
import NAvbar from "./navbar";
import { useNavigate } from "react-router-dom";
function ChatPage(props) {
  const [formData, setFormdata] = useState({})
  const [questions2, setQuestions2] = useState([]);
  const [selectedOption, setSelectedOption] = useState("");
  const [questions, setQuestions] = useState([]);
  useEffect(() => {
    async function fetchData() {
      axios.get('http://localhost:3001/questionsapi').then((response) => {
        const questions = response.data.questions
        setQuestions(questions)
      })
    }
    fetchData();
  }, []);
  console.log(questions)
  const handleClear = () => {
    setQuestions2([]);
  }
  var cook = new Cookies();
  var email_id = cook.get('email_id');
  const handleClearHistory = () => {
    axios.post('http://localhost:3001/historydeleteapi', { "email_id": email_id }).then((response) => {
      alert("History Deleted Succesfully")
    })
  }
  const handleChange = (event) => {
    setSelectedOption(event.target.value);
    const selectedQuestion = questions.find((question) => question._id === event.target.value);
    console.log(selectedQuestion)
    if (selectedQuestion) {
      setQuestions2([...questions2, selectedQuestion]);
    }
    var cook = new Cookies();
    var email_id = cook.get("email_id")
    const dataa = { selectedQuestion, email_id };
    axios.post('http://localhost:3001/inshistory', dataa).then((response) => {

      console.log("Entered Post")
      console.log(response)
    })
    console.log("Questions 2 : " + questions2)
  };
  const divRef = useRef(null);

  useEffect(() => {
    divRef.current.scrollIntoView({ behavior: 'smooth' });
  });
  if (!questions || !questions2) {
    return <div>Loading...</div>;
  }
  else {


    return (
      <div>
        <div>
          <div>
            <h1>GPT Lite</h1>
            <hr />
            <NAvbar></NAvbar>
            <h1>Chat Page</h1>
            <div>
              <div>
                <h1>Answers</h1><hr></hr></div>
              <center>
                <div
                  id="displayanswers"
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                >
                  <Grid columns={3}>
                    {questions2.map((question, index) => (
                      <Grid.Row key={index}>
                        <Grid.Column width={5}>
                          <Segment>
                            <b>Question:</b> {question.ques}
                            <br /><br />
                            <b>Answer:</b> {question.ans}
                          </Segment>
                        </Grid.Column>
                      </Grid.Row>
                    ))}
                  </Grid>
                </div>
              </center>
              <div style={{ position: 'fixed', bottom: 25, width: '100%' }}>
                <div>
                  <h3>
                  <b>Select a Question:    </b>
                  <select value={selectedOption} onChange={handleChange}>
                    <option value="">Select a question</option>
                    {questions.map((question) => (
                      <option key={question._id} value={question._id}>
                        {question.ques}
                      </option>
                    ))}
                  </select>   </h3>
                  {/* <br></br> <br></br> */}
                    <Button primary onClick={handleClear}>Clear Chat</Button>
                  <Button primary onClick={handleClearHistory}>Clear History</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div ref={divRef} />
      </div>
    );
  }
}


export default ChatPage;